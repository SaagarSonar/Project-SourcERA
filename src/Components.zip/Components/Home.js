import { Alert, Container } from "react-bootstrap";


export function Home(){
    return(
        <Container className="text-center mt-5">
            <Alert varient="primary">
                Welcome to Sourcera
            </Alert>
            <p>Please visit the Courses</p>
        </Container>
    );
}