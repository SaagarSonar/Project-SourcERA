import { Component } from "react";
import { Button, ButtonGroup, Container, Nav, Navbar, NavDropdown } from "react-bootstrap";
import { LinkContainer } from "react-router-bootstrap";

export class NavigationBar extends Component {
  render() {
    return (
      <Navbar bg="dark" variant="dark" expand="lg">
        <Container>
          <Navbar.Brand href="#home">SourcERA</Navbar.Brand>
          <Navbar.Toggle aria-controls="basic-navbar-nav" />
          <Navbar.Collapse id="basic-navbar-nav">
            <Nav className="me-auto">
              <LinkContainer to={"/"}>
                <Nav.Link>Home</Nav.Link>
              </LinkContainer>
              <LinkContainer to={"/about-us"}>
                <Nav.Link>About Us</Nav.Link>
              </LinkContainer>
              <NavDropdown title="ClassRoom Courses" id="basic-nav-dropdown">
                <LinkContainer to={"/autocad-mech"}>
                  <NavDropdown.Item>Mechanical AutoCAD</NavDropdown.Item>
                </LinkContainer>
                <LinkContainer to={"/autocad-civil"}>
                  <NavDropdown.Item>AutoCAD Civil</NavDropdown.Item>
                </LinkContainer>
                <LinkContainer to={"/autocad-electrical"}>
                  <NavDropdown.Item>AutoCAD Electrical</NavDropdown.Item>
                </LinkContainer>
                <LinkContainer to={"/catia"}>
                  <NavDropdown.Item>CATIA</NavDropdown.Item>
                </LinkContainer>
                <LinkContainer to={"/etabs"}>
                  <NavDropdown.Item>ETABS</NavDropdown.Item>
                </LinkContainer>
                <LinkContainer to={"/nx-cad"}>
                  <NavDropdown.Item>NX-CAD</NavDropdown.Item>
                </LinkContainer>
              </NavDropdown>
              <NavDropdown title="Online Courses" id="basic-nav-dropdown">
                <LinkContainer to={"/ccna"}>
                  <NavDropdown.Item>CCNA</NavDropdown.Item>
                </LinkContainer>
                <LinkContainer to={"/software-testing"}>
                  <NavDropdown.Item>Software Testing</NavDropdown.Item>
                </LinkContainer>
                <LinkContainer to={"/autocad-mech"}>
                  <NavDropdown.Item>Mechanical AutoCAD</NavDropdown.Item>
                </LinkContainer>
                <LinkContainer to={"/autocad-civil"}>
                  <NavDropdown.Item>AutoCAD Civil</NavDropdown.Item>
                </LinkContainer>
                <LinkContainer to={"/autocad-electrical"}>
                  <NavDropdown.Item>AutoCAD Electrical</NavDropdown.Item>
                </LinkContainer>
                <LinkContainer to={"/catia"}>
                  <NavDropdown.Item>CATIA</NavDropdown.Item>
                </LinkContainer>
                <LinkContainer to={"/etabs"}>
                  <NavDropdown.Item>ETABS</NavDropdown.Item>
                </LinkContainer>
                <LinkContainer to={"/nx-cad"}>
                  <NavDropdown.Item>NX-CAD</NavDropdown.Item>
                </LinkContainer>
              </NavDropdown>
              <LinkContainer to={"/placements"}>
                <Nav.Link>Placements</Nav.Link>
              </LinkContainer>
              <LinkContainer to={"/jobs"}>
                <Nav.Link>Jobs</Nav.Link>
              </LinkContainer>
              <LinkContainer to={"/signup"}>
                <Nav.Link>
                  {/* <Button variant="secondary">SignUp / SignIn </Button> */}
                  <ButtonGroup aria-label="Basic example">
                    <Button variant="dark">Sign Up</Button>
                    <Button variant="secondary">Sign In</Button>
                  </ButtonGroup>
                </Nav.Link>
              </LinkContainer>
              <LinkContainer to={"/payonline"}>
                <Nav.Link>
                  <Button variant="primary">PayNow</Button>
                </Nav.Link>
              </LinkContainer>
            </Nav>
          </Navbar.Collapse>
        </Container>
      </Navbar>
    );
  }
}
