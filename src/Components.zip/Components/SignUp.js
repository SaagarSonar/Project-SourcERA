import { Component } from "react";
import { Button, Card, Col, Container, Form, Row } from "react-bootstrap";
import { saveStudent } from "../Services/StudentAPIService";

export class SignUp extends Component {
  constructor() {
    super();
    this.state = {
      STUDENT_NAME: "",
      EMAIL_ID: "",
      MOBILENO: "",
      PASSWORD: "",
    };
  }

  handelChange=(event)=>{
    this.setState({[event.target.name]:event.target.value});
  }

  handelSubmit= async(event)=>{
    //preventing its default property of refreshing the page
    event.preventDefault();
    
    //sending a request to the server function to save the student data
    //pasing state as an argument as state has entire form data
    //saveStudent will send a promise within which it has a response
    //saveStudent will call to post method
    const response = await saveStudent(this.state);

    //in the post method on server it returns either the error or the json object
    console.log(response);
  }
  render() {
    return (
      <Container>
        <Card className="mt-4">
          <Row>
            <Col lg={6}>
              {/* <Card.Title>Sign Up</Card.Title> */}
              <h3>Sign Up</h3>
              <br></br>
              <Form className="mx-4" onSubmit={this.handelSubmit}>
                <Form.Group className="mb-3">
                  <Form.Label>Full Name</Form.Label>
                  <Form.Control type="text" placeholder="Enter Name" name="STUDENT_NAME" onChange={this.handelChange}/>
                </Form.Group>
                <Form.Group className="mb-3">
                  <Form.Label>Email-id</Form.Label>
                  <Form.Control type="email" placeholder="Enter Email-id" name="EMAIL_ID" onChange={this.handelChange}/>
                </Form.Group>
                <Form.Group className="mb-3">
                  <Form.Label>Mobile No</Form.Label>
                  <Form.Control type="text" placeholder="Enter Mobile No." name="MOBILENO" onChange={this.handelChange}/>
                </Form.Group>
                <Form.Group className="mb-3">
                  <Form.Label>Create Password</Form.Label>
                  <Form.Control type="password" placeholder="Create Password" name="PASSWORD" onChange={this.handelChange}/>
                </Form.Group>
                <Form.Group className="mb-3">
                  <Form.Label>Confirm Password</Form.Label>
                  <Form.Control
                    type="password"
                    placeholder="Conform Password"
                  />
                </Form.Group>
                <Button variant="primary" type="submit" className="center">
                  Sign Up
                </Button>
              </Form>
              <Card.Text className="mx-4 mb-5">
                Already have a account?{" "}
                <Card.Link href="/sign-in ">Sign In</Card.Link>
              </Card.Text>
            </Col>

            <Col lg={6}>
              <Card className="bg-dark align-center justify-center">
                <Card.Img src="login.jpg" alt="Card image" />
              </Card>
            </Col>
          </Row>
        </Card>
      </Container>
    );
  }
}

//export function SignUp() {
  // return (
  //   <Container>
  //     <Card className="mt-4">
  //       <Row>
  //         <Col lg={6}>
  //           {/* <Card.Title>Sign Up</Card.Title> */}
  //           <h3>Sign Up</h3><br></br>
  //           <Form className="mx-4">
  //             <Form.Group className="mb-3">
  //               <Form.Label>Full Name</Form.Label>
  //               <Form.Control type="text" placeholder="Enter Name" />
  //             </Form.Group>
  //             <Form.Group className="mb-3">
  //               <Form.Label>Email-id</Form.Label>
  //               <Form.Control type="email" placeholder="Enter Email-id" />
  //             </Form.Group>
  //             <Form.Group className="mb-3">
  //               <Form.Label>Mobile No</Form.Label>
  //               <Form.Control type="text" placeholder="Enter Mobile No." />
  //             </Form.Group>
  //             <Form.Group className="mb-3">
  //               <Form.Label>Create Password</Form.Label>
  //               <Form.Control type="password" placeholder="Create Password" />
  //             </Form.Group>
  //             <Form.Group className="mb-3">
  //               <Form.Label>Confirm Password</Form.Label>
  //               <Form.Control type="password" placeholder="Conform Password" />
  //             </Form.Group>
  //             <Button variant="primary" type="submit" className="center">
  //               Sign Up
  //             </Button>
  //           </Form>
  //           <Card.Text className="mx-4 mb-5">
  //             Already have a account? <Card.Link href="/sign-in ">Sign In</Card.Link>
  //           </Card.Text>
  //         </Col>
  //         <Col lg={6}>
  //           <Card className="bg-dark align-center justify-center">
  //             <Card.Img src="login.jpg" alt="Card image" />
  //           </Card>
  //         </Col>
  //       </Row>
  //     </Card>
  //   </Container>
  // );
//}
